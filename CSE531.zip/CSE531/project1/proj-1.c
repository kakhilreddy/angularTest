
/* 
CSE 531 DMOS --- Project - 1
Team members : Akhil Reddy Katpally, Tejas Ruikar  
*/

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "sem.h"
#include <unistd.h>
#define N 3
semaphore_t child1, child2,child3, parent;
int arr[N];

void function_1()
{
    while (1)
    {
        P(&child1);
        
        printf("Child 1 added 1 to array[0]\n");
        arr[0] += 1;
       
        sleep(1);
    
        
       
        V(&child2);
    }
}

void function_2()
{
    while (1)
    {
        P(&child2);
        
        printf("Child 2 added 1 to array[1]\n");
        arr[1] += 1;
       
        sleep(1);
       
        V(&child3);
    }
}

void function_3()
{
    while (1)
    {
        P(&child3);
      
    printf("Child 3 added 1 to array[2]\n");
        arr[2] += 1;
    
        sleep(1);
        V(&parent);
     
    }
}

int main()
{
    init_sem(&child1, 1);
    init_sem(&child2, 0);
    init_sem(&child3, 0);
    init_sem(&parent, 0);
    int i = 0;

    for (i = 0; i < N; i++)
    {
        arr[i] = 0;
    }

    start_thread(function_1, NULL);
    start_thread(function_2, NULL);
    start_thread(function_3, NULL);

    while (1)
    {

        P(&parent);
        printf("Parent:  Printing contents of array: ");
        for (i = 0; i < N; i++)
        {
            printf("%d ", arr[i]);
        }
        printf("\n");
        sleep(1);

        V(&child1);

    }
}
