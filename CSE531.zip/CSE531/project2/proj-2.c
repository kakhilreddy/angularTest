

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "threads.h"

int global=0;

void function_1()
{
   int local = 0;

    while (1){
      //  printf("XXXXPrinting from Function 1  global = %d  local = %d\n", global, local);
        sleep(1);
        global++; local ++;
        printf("Function 1 incremented .... global = %d  local = %d\n", global, local);
        sleep(1);
        yield();
    }
}    

void function_2()
{
   int local = 0;

    while (1){
     //   printf("XXXXPrinting from Function 2 global = %d  local = %d\n", global, local);
        sleep(1);
        global++; local --;
        printf("Function 2 incremented .... global = %d  local = %d\n", global, local);
        sleep(1);
        yield();
    }
}    

 




int main()
{   start_thread(function_1);
     start_thread(function_2); // there is a serious bug here, left it in for demo purposes
    
     run();

    while(1) sleep(1); // infinite loop

    return 0;
}



