
#include<stdio.h>
#include <stdlib.h>
#include "TCB.h"




void AddQueue(struct TCB_t** head, struct TCB_t* item) {
    // size 0
 
    struct TCB_t *headTemp = *head;
       
    if(headTemp == NULL) {
      

        headTemp = item;
      
       headTemp->next = item;
      headTemp->prev = item;
      *head = headTemp;
     
    } else{
       struct TCB_t* rear = headTemp->prev;
       rear->next = item;
        headTemp->prev = item;
       item->prev = rear;
       item->next = headTemp;
      
    }

 

  

}

struct TCB_t* DelQueue(struct TCB_t** head) {
    struct TCB_t* deleteNode = *head;

    if(!deleteNode) {
        printf("ERROR-- ReadyQ is empty . Cannot perform delete operation");
        return NULL;
    }
    if(deleteNode->next == deleteNode) {
        *head = NULL;
        return deleteNode;
    }
    deleteNode->next->prev = deleteNode->prev;
            deleteNode->prev->next = deleteNode->next;
            *head = (*head)->next;
  
    
   
   return deleteNode;

}
/*
void printQueue(struct TCB_t * head) {

if(!head)
return;
    struct TCB_t* temp = head;
    while(temp->next != head) {
        printf("%d ", temp->item);
        temp = temp->next;
    }
      printf("%d\n", temp->item);

}*/
