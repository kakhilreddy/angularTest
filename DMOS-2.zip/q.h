

#include "tcb.h"

void AddQueue(struct TCB_t **head, struct TCB_t *item)
{

    struct TCB_t *headTemp = *head;

    if (headTemp == NULL)
    {

        headTemp = item;

        headTemp->next = item;
        headTemp->prev = item;
        *head = headTemp;
    }
    else
    {
        struct TCB_t *rear = headTemp->prev;
        rear->next = item;
        headTemp->prev = item;
        item->prev = rear;
        item->next = headTemp;
    }
  //  printf("added element %d", item->thread_id);
}

struct TCB_t *DelQueue(struct TCB_t **head)
{
    struct TCB_t *deleteNode = *head;

    if (!deleteNode)
    {
        printf("ERROR-- ReadyQ is empty . Cannot perform delete operation");
        return NULL;
    }
    if (deleteNode->next == deleteNode)
    {
        *head = NULL;
        return deleteNode;
    }
    deleteNode->next->prev = deleteNode->prev;
    deleteNode->prev->next = deleteNode->next;
    *head = (*head)->next;

    return deleteNode;
}
