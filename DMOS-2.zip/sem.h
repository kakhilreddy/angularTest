

#include "threads.h"


typedef struct semaphore_t {
  int count;
  TCB_t* semQ;
    
} semaphore_t;

semaphore_t* createSem(int i)
{   
  semaphore_t * newSem = (semaphore_t *)malloc(sizeof(semaphore_t));
    newSem->count = i;
    newSem->semQ = NULL;
    return newSem;
}


/*
 * The P routine decrements the semaphore, and if the value is less than
 * zero then blocks the process 
 */
void P(semaphore_t *sem)
{   
  
    sem->count--;
    if (sem->count < 0) {
      Curr_Thread = DelQueue(&ReadyQ);
AddQueue(&(sem->semQ),Curr_Thread);


  swapcontext(&(Curr_Thread->context), &(ReadyQ->context));
    }
 
}


/*
 * The V routine increments the semaphore, and if the value is 0 or
 * negative, wakes up a process and yields
 */

void V(semaphore_t * sem)
{   
    
    sem->count++;
    if (sem->count <= 0) {

AddQueue(&ReadyQ,  DelQueue(&(sem->semQ)));

    }
    yield();
   
 
}


