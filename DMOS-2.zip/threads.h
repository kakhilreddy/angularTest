#include <stdlib.h>

#include "q.h"
int thread_id = 0;
struct TCB_t *ReadyQ;
struct TCB_t *Curr_Thread;

void start_thread(void (*function)(void))
{ // begin pseudo code
    //   allocate a stack (via malloc) of a certain size (choose 8192)
    void *stack = malloc(8192);
    struct TCB_t *tcb = (struct TCB_t *)malloc(sizeof(struct TCB_t));
    init_TCB(tcb, function, stack, 8192);

    thread_id++;
    tcb->thread_id = thread_id;
    //printf("TCB created %d", tcb->thread_id);
    AddQueue(&ReadyQ, tcb);
    //  call addQ to add this TCB into the “ReadyQ” which is a global header pointer
    //end pseudo code
}

void run()

{ // real code

   
    Curr_Thread = ReadyQ;

    ucontext_t parent; // get a place to store the main context, for faking

    getcontext(&parent); // magic sauce

    swapcontext(&parent, &(Curr_Thread->context)); // start the first thread
}

void yield() // similar to run
{
    struct TCB_t *Prev_Thread;
    Prev_Thread = DelQueue(&ReadyQ);
   
    AddQueue(&ReadyQ,Prev_Thread);
    Curr_Thread = ReadyQ;
    // swap the context, from Prev_Thread to the thread pointed to Curr_Thread
    swapcontext(&(Prev_Thread->context), &(Curr_Thread->context));
}
int getCurrentThreadID()
{
    return Curr_Thread->thread_id;
}